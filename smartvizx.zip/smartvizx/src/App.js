import React, { Component } from 'react';
import './App.css';
class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data:"",
            dataType:"",
            revString:""
        };
    }
     onFieldChnage(e){
        try {
            this.setState({
                data:e.target.value
            },()=>{
                this.validate()
            })
        } catch (error) {
            console.log(error)

        }
    }
    validate(e) {
        try {
            var urlPattern = "((http|https)://)(www.)?"
                + "[a-zA-Z0-9@:%._\\+~#?&//=]"
                + "{2,256}\\.[a-z]"
                + "{2,6}\\b([-a-zA-Z0-9@:%"
                + "._\\+~#?&//=]*)";

            if (this.state.data.match(/\.(jpeg|jpg|gif|png)$/) != null) {
                this.setState({
                    dataType: "img"
                }, () => {
                    console.log("dataType leseee", this.state.dataType)
                })
            } else if (this.state.data.match(urlPattern)) {
                this.setState({
                    dataType: "url"
                }, () => {
                    console.log("dataType", this.state)
                })

            }
            else {
                this.setState({
                    dataType: "text"
                }, () => {
                    console.log("dataType", this.state)
                })

            }

        } catch (error) {
            console.log(error)

        }
    }
    revString(e){
        this.setState({
            revString:e.target.value
        })
    }
    isLetter(char){
        return ( (char >= 'A' &&  char <= 'Z') ||
                 (char >= 'a' &&  char <= 'z') );
    }    
    
    reverseSpecialString(string){
        let str = string.split('');
        let i = 0;
        let j = str.length-1;
        while(i<j){
            if(!this.isLetter(str[i])){
                ++i;
            }
            if(!this.isLetter(str[j])){
                --j;
            }
            if(this.isLetter(str[i]) && this.isLetter(str[j])){
                var tempChar = str[i];
                str[i] = str[j];
                str[j] = tempChar;
                ++i;
                --j;
            }
        }
        return str.join('');
    }
    render() {
        return (
            <React.Fragment>
                <div className="body__wrap">
                    <div className="grid dot">
                        <div className="body__grid">
                            <div className="child c1"></div>
                            <div className="child c2"></div>
                            <div className="child c3"></div>
                            <div className="child c4"></div>
                            <div className="child c5"></div>
                            <div className="child c6"></div>
                            <div className="child c7"></div>
                            <div className="child c8"></div>
                            <div className="child c9"></div>
                            <div className="child c10"></div>
                            <div className="child c11"></div>
                            <div className="child c12"></div>
                            <div className="child c13"></div>
                            <div className="child c14"></div>
                            <div className="child c15"></div>
                            <div className="child c16"></div>
                            <div className="child c17"></div>
                            <div className="child c18"></div>
                            <div className="child c19"></div>
                            <div className="child c20"></div>
                            <div className="child c21"></div>
                            <div className="child c22"></div>
                            <div className="child c23"></div>
                            <div className="child c24"></div>
                            <div className="child c25"></div>
                        </div>
                    </div>
                    <span>Grid</span>

                    <div className="checkers dot">
                            <div className="body__grid">
                                <div className="child c1"></div>
                                <div className="child c2"></div>
                                <div className="child c3"></div>
                                <div className="child c4"></div>
                                <div className="child c5"></div>
                                <div className="child c6"></div>
                                <div className="child c7"></div>
                                <div className="child c8"></div>
                                <div className="child c9"></div>
                                <div className="child c10"></div>
                                <div className="child c11"></div>
                                <div className="child c12"></div>
                                <div className="child c13"></div>
                                <div className="child c14"></div>
                                <div className="child c15"></div>
                                <div className="child c16"></div>
                                <div className="child c17"></div>
                                <div className="child c18"></div>
                                <div className="child c19"></div>
                                <div className="child c20"></div>
                                <div className="child c21"></div>
                                <div className="child c22"></div>
                                <div className="child c23"></div>
                                <div className="child c24"></div>
                                <div className="child c25"></div>
                            </div>
                    </div>
                    <span>Checkers</span>
                    <div className="odd dot">
                            <div className="body__grid">
                                <div className="child c1"></div>
                                <div className="child c2"></div>
                                <div className="child c3"></div>
                                <div className="child c4"></div>
                                <div className="child c5"></div>
                                <div className="child c6"></div>
                                <div className="child c7"></div>
                                <div className="child c8"></div>
                                <div className="child c9"></div>
                                <div className="child c10"></div>
                                <div className="child c11"></div>
                                <div className="child c12"></div>
                                <div className="child c13"></div>
                                <div className="child c14"></div>
                                <div className="child c15"></div>
                                <div className="child c16"></div>
                                <div className="child c17"></div>
                                <div className="child c18"></div>
                                <div className="child c19"></div>
                                <div className="child c20"></div>
                                <div className="child c21"></div>
                                <div className="child c22"></div>
                                <div className="child c23"></div>
                                <div className="child c24"></div>
                                <div className="child c25"></div>
                            </div>
                           
                    </div>
                    <span>Odd</span>
                </div>
                <span>Text parser</span>
                <div class="d-flex">
                   
                    <div class="p-2 bg-info flex-fill">
                       <input type="text" className="form-control" placeholder={"Type here"} name="textleft" value={this.state.data} onChange={(e)=>{this.onFieldChnage(e)}}/>
                        </div>
                    <div class="p-2 bg-warning flex-fill">

                       {(this.state.dataType=="text")?
                       <React.Fragment>
                        {this.state.data}
                       </React.Fragment>
                       :(this.state.dataType=="url")?
                       <React.Fragment>
                      <a href={this.state.data} target="_blank">{this.state.data}</a>
                      </React.Fragment>
                      :
                      <React.Fragment>
                          <img src={this.state.data}/>
                      </React.Fragment>
                       
                       }
                        </div>
               </div>


               <span>Reverse A STring</span>
                <div class="d-flex">
                   
                    <div class="p-2 bg-info flex-fill">
                       <input type="text" className="form-control" placeholder={"Type here"}  value={this.state.revString} onChange={(e)=>{this.revString(e)}}/>
                        </div>
                    <div class="p-2 bg-warning flex-fill">

                      {this.reverseSpecialString(this.state.revString)}
                        </div>
               </div>
            </React.Fragment>
        )

    }
}
export default App;

